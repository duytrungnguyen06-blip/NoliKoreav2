const test = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs");
const { app } = require("./helpers.cjs"),
  L = require("../dist/modules/learning-content.js"),
  Store = require("../dist/modules/data-store.js");
const base = JSON.parse(fs.readFileSync("dist/curriculum.json"));
test("lazy exercise tabs render once and resume saved answers and drafts", async () => {
  const a = await app();
  try {
    a.w.openStudyModal("s1", "b1a", "l_snu1a_01");
    assert.equal(a.w.KoreanRecall.exercises.length, 0);
    assert.equal(a.w.KoreanProduction.exercises.length, 0);
    a.w.switchStudyTab("recall");
    const order = a.w.KoreanRecall.exercises.map((x) => x.id).join();
    const ex = a.w.KoreanRecall.exercises.find((x) => x.type === "choice");
    a.w.KoreanRecall.checkChoice(
      ex.id,
      ex.correct,
      a.w.document.querySelector(".recall-opt-btn"),
    );
    a.w.switchStudyTab("production");
    a.w.closeStudyModal();
    a.w.load();
    a.w.openStudyModal("s1", "b1a", "l_snu1a_01");
    assert.equal(a.w.KoreanRecall.exercises.length, 0);
    a.w.switchStudyTab("recall");
    assert.equal(a.w.KoreanRecall.exercises.map((x) => x.id).join(), order);
    assert.equal(
      a.w.KoreanRecall.exercises.find((x) => x.id === ex.id).state,
      "correct",
    );
    assert.deepEqual(a.errors, []);
  } finally {
    a.close();
  }
});
test("infinite stream reads real SRS/mistakes queues, avoids 1-word scramble and updates outcomes", async () => {
  const a = await app();
  try {
    const w = a.w;
    w.recordMistake({ korean: "사과", vi: "Quả táo", lessonId: "b1a_l6" });
    w.NoliInfiniteStream.open({ mode: "mistakes" });
    const st = w.NoliInfiniteStream.getState();
    assert.ok(st.cards.length > 0);
    assert.ok(
      st.cards
        .filter((c) => c.type === "cloze_scramble")
        .every((c) => c.targetSentence.split(/\s+/).length >= 2),
    );
    w.NoliInfiniteStream.setFilter("all");
    const choiceIdx = w.NoliInfiniteStream
      .getState()
      .cards.findIndex((c) => c.type === "quick_choice" || c.type === "listening_cd");
    if (choiceIdx >= 0) {
      const card = w.NoliInfiniteStream.getState().cards[choiceIdx];
      w.NoliInfiniteStream.handleChoice(choiceIdx, card.correctAnswer);
      assert.equal(w.NoliInfiniteStream.getState().sessionStats.correct, 1);
      assert.ok(w.db.streak.count >= 1);
    }
    w.NoliInfiniteStream.close();
    assert.deepEqual(a.errors, []);
  } finally {
    a.close();
  }
});
test("queue prioritizes due items, deduplicates Korean and uses same-category distractors", () => {
  const db = Store.validate(base),
    all = L.flatten(db),
    target = all.find((i) => i.korean === "월요일");
  db.itemReviews[L.key(target)] = { ...target, level: 0, lapses: 2, dueAt: 1 };
  const q = L.queue(db, 2);
  assert.equal(q[0].korean, "월요일");
  assert.equal(new Set(q.map((i) => L.normalize(i.korean))).size, q.length);
  const ds = L.distractors(target, all, "korean");
  assert.equal(ds.length, 3);
  assert.ok(ds.every((x) => x.endsWith("요일")));
  assert.ok(
    L.isAnswer("뭐", { korean: "무엇 (뭐)", acceptedAnswers: ["무엇", "뭐"] }),
  );
  assert.ok(
    !L.isAnswer("어디", {
      korean: "무엇 (뭐)",
      acceptedAnswers: ["무엇", "뭐"],
    }),
  );
});
test("two stores reject stale writes and replacements; unchanged saves do not write", () => {
  const map = new Map();
  let writes = 0;
  const mem = {
    getItem: (k) => map.get(k) ?? null,
    setItem: (k, v) => {
      writes++;
      map.set(k, v);
    },
  };
  const one = Store.create(mem, base),
    d1 = one.read(),
    two = Store.create(mem, base),
    d2 = two.read();
  const n = writes;
  one.save(d1);
  assert.equal(writes, n);
  d1.stages[0].name = "Edited";
  one.save(d1);
  const raw = mem.getItem(Store.KEY);
  assert.throws(
    () => two.save(d2),
    (e) => e.code === "STALE_DATA",
  );
  assert.throws(
    () => two.replace(d2, "test"),
    (e) => e.code === "STALE_DATA",
  );
  assert.equal(mem.getItem(Store.KEY), raw);
});
test("content flags persist safely and malformed short sessions are rejected", async () => {
  const a = await app();
  try {
    a.w.prompt = () => "<img src=x> cần xem";
    a.w.ContentFeedback.flag({
      sid: "s1",
      bid: "b1a",
      lid: "l_snu1a_01",
      korean: "안녕",
      vi: "Chào",
    });
    a.w.load();
    a.w.ContentFeedback.render();
    assert.equal(a.w.db.contentFlags[0].note, "<img src=x> cần xem");
    assert.equal(a.w.document.querySelector("#contentFlags img"), null);
    const bad = structuredClone(base);
    bad.dailyPractice = {
      seen: [],
      history: [],
      active: { id: "test", cards: [] },
    };
    assert.throws(() => Store.validate(bad));
    assert.deepEqual(a.errors, []);
  } finally {
    a.close();
  }
});
test("bundled content sources agree and known translation corrections preserve review schedule", () => {
  assert.deepEqual(require("../dist/curriculum-data.js"), base);
  const before = structuredClone(base);
  const corrections = JSON.parse(fs.readFileSync("content-corrections.json"));
  const c = corrections.find((c) => c.korean === "테니스");
  const i = before.stages[0].books[0].lessons
    .find((l) => l.id === c.lid)
    .items.find((i) => i.korean === c.korean);
  i.vi = c.old;
  const db = Store.validate(before);
  const old = JSON.stringify([c.sid, c.bid, c.lid, c.korean, c.old]);
  db.itemReviews[old] = { ...c, vi: c.old, level: 2, lapses: 1, dueAt: 123456 };
  const packed = Store.pack(db, before);
  const updated = Store.unpack(packed, base);
  const key = JSON.stringify([c.sid, c.bid, c.lid, i.id]);
  assert.equal(updated.itemReviews[key].dueAt, 123456);
  assert.ok(!updated.itemReviews[old]);
});
test("Web Locks permits only one writer and releases on page exit", async () => {
  let held = false;
  const locks = {
    request: async (name, options, callback) => {
      if (held) return callback(null);
      held = true;
      try {
        return await callback({ name });
      } finally {
        held = false;
      }
    },
  };
  const setup = (w) =>
    Object.defineProperty(w.navigator, "locks", { value: locks });
  const a = await app({}, undefined, setup),
    b = await app({}, undefined, setup);
  try {
    assert.doesNotThrow(() => a.w.TabSync.assertWritable());
    assert.throws(
      () => b.w.TabSync.assertWritable(),
      (e) => e.code === "READ_ONLY_TAB",
    );
    a.w.dispatchEvent(new a.w.Event("pagehide"));
    await new Promise((r) => setTimeout(r, 0));
    b.w.document.querySelector("#tabConflict .btn-primary").click();
    await new Promise((r) => setTimeout(r, 0));
    assert.doesNotThrow(() => b.w.TabSync.assertWritable());
    assert.deepEqual(a.errors, []);
    assert.deepEqual(b.errors, []);
  } finally {
    b.w.dispatchEvent(new b.w.Event("pagehide"));
    a.close();
    b.close();
  }
});
test("V7.2 auto-lands on active 1A book, filters lessons, serves Input grammar/situations & Roleplay blind/number STT", async () => {
  const a = await app();
  try {
    const w = a.w;
    assert.equal(w.nav.sid, "s1");
    assert.equal(w.nav.bid, "b1a");
    assert.ok(w.document.querySelectorAll("#lessonList .lesson-card").length >= 8);
    assert.ok(w.document.querySelector(".lesson-grammar-tag"));
    assert.ok(w.document.querySelector("[data-quick-stream]"));

    w.recordMistake({ korean: "사과", vi: "Quả táo", lessonId: "b1a_l6" });
    w.setLessonFilter("mistakes");
    const filteredCards = w.document.querySelectorAll("#lessonList .lesson-card");
    assert.equal(filteredCards.length, 1);
    assert.match(filteredCards[0].textContent, /Bài 6/);
    w.setLessonFilter("all");

    w.openStudyModal("s1", "b1a", "b1a_l2");
    assert.ok(w.KLALearning.explainPhonetic("시계", "시게").rule.includes("Đơn giản hóa"));
    w.setInputSubPanel("grammar");
    assert.ok(!w.document.getElementById("inputGrammarPanel").classList.contains("hidden"));
    assert.ok(w.document.querySelectorAll("#inputGrammarCards .input-grammar-card").length >= 2);
    w.setInputSubPanel("situations");
    assert.ok(!w.document.getElementById("inputSituationsPanel").classList.contains("hidden"));
    assert.equal(w.document.querySelectorAll("#inputSituationsList .input-situation-card").length, 16);
    w.setInputSubPanel("vocab");

    assert.equal(w.KoreanVoice.calculateAccuracy("이천 원", "2000원"), 100);
    assert.equal(w.KoreanVoice.calculateAccuracy("사과 세 개", "사과 3개"), 100);
    assert.deepEqual(a.errors, []);
  } finally {
    a.close();
  }
});
test("V7.3 natural acquisition adds lexical chunks, minimal pairs, 3-pass/shadowing & Chill Zen stream", async () => {
  const a = await app();
  try {
    const w = a.w;
    assert.ok(w.KLALearning.chunkFor({ korean: "공부하다" }).includes("공부해요"));
    assert.ok(w.KLALearning.lessonMeta("b1a_l4").minimalPairs.length >= 2);

    w.openStudyModal("s1", "b1a", "b1a_l3");
    assert.ok(w.document.querySelector(".study-chunk-pill"));
    w.cycleDialogueImmersionPass("b1a_l3");
    assert.equal(w._dialogueImmersionPass["b1a_l3"], 1);
    w.setInputSubPanel("grammar");
    assert.ok(w.document.querySelector(".input-minimal-pairs-card"));
    w.closeStudyModal();

    const beforeMistakes = w.db.mistakes.length;
    w.NoliInfiniteStream.open({ filter: "immersion" });
    const modal = w.document.getElementById("infiniteStreamModal");
    assert.ok(modal.classList.contains("chill-zen-mode"));
    assert.ok(w.NoliInfiniteStream.getState().cards.some((c) => c.type === "chill_immersion"));
    const laterBtn = w.document.querySelector('[data-stream-action="chill-later"]');
    assert.ok(laterBtn);
    laterBtn.click();
    assert.equal(w.db.mistakes.length, beforeMistakes);
    w.NoliInfiniteStream.close();
    assert.deepEqual(a.errors, []);
  } finally {
    a.close();
  }
});
test("V7.4 Think in Korean adds concept cues, monolingual QA, Zen blur & daily inner monologue", async () => {
  const a = await app();
  try {
    const w = a.w;
    assert.ok(w.KLALearning.conceptCue("한강")?.visual);
    assert.equal(w.KLALearning.koreanQAs("l_snu1a_01").length, 3);
    assert.equal(w.KLALearning.koreanQAs().length, 24);

    assert.ok(w.document.querySelector(".inner-monologue-bar"));
    w.selectInnerMonologue(0);
    assert.ok(w.document.querySelector(".inner-monologue-reply"));

    w.openStudyModal("s1", "b1a", "b1a_l8");
    w.toggleThinkKorean();
    assert.ok(w.KLALearning.isThinkKorean());
    assert.ok(w.document.body.classList.contains("think-korean-mode"));
    assert.ok(w.document.getElementById("btnThinkKorean").classList.contains("active"));
    assert.ok(w.document.querySelector("#studyContent .think-vi-blur"));

    w.switchStudyTab("recall");
    assert.ok(w.KoreanRecall.exercises.some((e) => e.type === "korean_qa"));

    w.switchStudyTab("production");
    assert.ok(w.document.querySelector(".prod-think-toggle.active"));
    assert.ok(w.document.querySelectorAll(".think-vi-blur").length > 0);

    w.toggleThinkKorean();
    assert.equal(w.KLALearning.isThinkKorean(), false);
    w.closeStudyModal();

    w.NoliInfiniteStream.open({ filter: "korean_qa" });
    assert.equal(w.NoliInfiniteStream.getState().filter, "korean_qa");
    assert.ok(w.NoliInfiniteStream.getState().cards.some((c) => c.type === "korean_qa"));
    w.NoliInfiniteStream.setFilter("immersion");
    assert.equal(w.NoliInfiniteStream.getState().chillBlurVi, true);
    const blurBtn = w.document.querySelector('[data-stream-action="toggle-chill-blur"]');
    assert.ok(blurBtn);
    blurBtn.click();
    assert.equal(w.NoliInfiniteStream.getState().chillBlurVi, false);
    w.NoliInfiniteStream.close();
    assert.deepEqual(a.errors, []);
  } finally {
    a.close();
  }
});
