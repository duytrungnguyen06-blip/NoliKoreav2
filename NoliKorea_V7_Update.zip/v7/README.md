# NoliKorea · V7.4.0

> **Ứng dụng tự học tiếng Hàn giao tiếp thực chiến theo giáo trình Đại học Quốc gia Seoul (Seoul 1A).**  
> Chạy hoàn toàn Offline (100% Local / Zero-Server Architecture), tích hợp PWA cài đặt trên máy tính & điện thoại di động, trợ lý AI thông minh Noli Shiba.

---

## 🌟 Điểm nổi bật trên Phiên bản V7.4.0

### 🧠 Tư Duy Trực Tiếp Bằng Tiếng Hàn (Think in Korean)
- **Mờ tiếng Việt mặc định trong `☕ Thư giãn`:** Che mờ bản dịch tiếng Việt khi nghe hiểu tự nhiên (chạm nhẹ 1 chạm để hé xem khi cần), tránh đọc chữ Việt trước khi tai nghe kịp tiếng Hàn.
- **Chế độ `🧠 Nghĩ tiếng Hàn` bật/tắt 1 chạm (Study · Recall · Production):** Ẩn/mờ câu dẫn tiếng Việt và thay bằng biểu tượng ngữ cảnh trực quan + gợi ý khái niệm thuần Hàn (`CONCEPT_CUES`), giúp não gắn trực tiếp âm–hình–tình huống.
- **Hội thoại hỏi–đáp Thuần Hàn (`💬 응대 · Thuần Hàn` / `🇰🇷 Thuần Hàn`):** 24 cặp Hỏi–Đáp 100% tiếng Hàn cho đủ 8 bài SNU 1A, tích hợp trực tiếp vào `Recall` và `NoliInfiniteStream`.
- **Thẻ Tự Thoại Nội Tâm Hằng Ngày (`오늘의 혼잣말`):** Đổi nhanh 4 tình huống tự nhủ bằng tiếng Hàn trong đời sống ngay đầu tab Giáo trình SNU 1A.

### 🌊 1. Hấp Thụ Ngôn Ngữ Tự Nhiên (Natural SLA Immersion)
- **Chế độ `☕ Thư giãn` (Chill Immersion Flow) trong Dòng chảy vô tận:** Lướt nghe hiểu các câu hoàn chỉnh ở tốc độ chuẩn `1.0x` theo cụm từ vựng tự nhiên, ẩn thanh XP/điểm số để đầu óc thoải mái, chạm 1 lần (`✓ Đã quen tai` / `🔁 Nghe lại sau` không ghi lỗi) hoặc bật **`⏯️ Tự phát rảnh tay`** (đọc `1.0x` $\rightarrow$ nghỉ `2.2s` $\rightarrow$ tự chuyển thẻ).
- **Học theo Cụm Tự Nhiên (*Lexical Chunks*):** Tự động gắn cụm câu giao tiếp mẫu kèm loa `🔊` ngay dưới mỗi từ đơn Bài 2–8 trong tab `Input`.
- **Tắm Hội Thoại 3 Lượt & Nhẩm Nhịp (`2s`):** Chuyển nhanh 3 lượt nghe hội thoại (*Bối cảnh* $\rightarrow$ *Khớp chữ* $\rightarrow$ *Toàn văn*) và nút **`🔁 Nhẩm nhịp (2s)`** đọc nối tiếp tô sáng từng câu thoại không áp lực chấm micro.
- **Cặp Đối Chiếu Tối Thiểu (*Minimal Sentence Pairs*):** Tích hợp dải **`🎧 Nghe phân biệt 2 giây`** ngay trong `📐 Ngữ pháp & Biến âm` để tai tự nhận ra quy luật ngữ pháp.

### 📚 2. Giao Diện Giáo Trình SNU 1A & Học Liệu Chuyên Sâu (V7.2)
- **Mở thẳng Quyển 1A (Smart Auto-Landing):** Khi chỉ có 1 quyển đang học có nội dung, tab Giáo trình tự mở thẳng danh sách 8 bài SNU 1A (giảm 2 cú bấm qua Giai đoạn/Quyển), kèm thanh lọc nhanh (`Tất cả`, `⏰ Cần ôn`, `📖 Đang học`, `📓 Có lỗi`).
- **Thẻ Bài Học giàu thông tin:** Gắn Tag Ngữ pháp trọng tâm từng bài, cấp độ SRS / tiến độ đang học dở, số lỗi sai chưa tốt nghiệp và nút hành động nhanh **`🎧 CD`** + **`⚡ Lướt ôn`**.
- **Học liệu SNU 1A mở rộng gấp đôi & tương tác:** Mở rộng lên **192 câu thực hành (`24`/bài)** và **128 tình huống thực tế (`16`/bài)**; bổ sung sub-tab **`📐 Ngữ pháp & Biến âm`** và **`💬 Tình huống`** trong `Input`, tooltip giải thích quy tắc âm vị học chuẩn Hàn (`연음`, `경음화`, `거센소리되기`, `모음 단순화`, `비음화`) khi chạm badge phát âm, chế độ **`🙈 Phản xạ mù`** trong Roleplay và chuẩn hóa số khi chấm nói STT.

### ♾️ 2. Noli Infinite Flow Engine & Tối Ưu Input → Recall → Production (V7.1)
- **Thay thế hoàn toàn "Phiên ngắn" cũ:** Loại bỏ `daily-session.js` khỏi runtime, thay bằng nút lối tắt **`⚡ Dòng chảy vô tận`** đối xứng cạnh nút **`Tiếp tục bài học`** trên bảng điều khiển (`#learningDashboard`).
- **Kết nối dữ liệu thực tế & Bộ lọc Chế độ:** Đồng bộ trực tiếp với lịch ôn SRS (`KLAScheduler.due` & `db.itemReviews`), Sổ tay lỗi sai (`db.mistakes`), và hỗ trợ chuyển nhanh 4 chế độ (`🎯 Toàn diện`, `🎧 Chỉ nghe`, `📓 Sổ lỗi`, `✍️ Gõ Hangul`) kèm Combo Multiplier (`x1.2` / `x1.5` XP).

### 🧠 2. Tối Ưu Chuyên Sâu Chu Trình Input → Recall → Production
- **Input (Chuẩn SNU 1A):** Phân tách badge phát âm `[시게]`, `[임니다]`, bật/tắt chế độ **Che chữ Hàn** tự kiểm tra ngay trên danh sách, nghe lại nhanh `<4s` tự hạ tốc độ `0.8x`, và mở rộng bộ giải phẫu `KoreanAnatomy` phủ đủ từ vựng & bất quy tắc Bài 1–8.
- **Recall:** Gợi ý tiến triển 3 nấc dùng phụ âm đầu chuẩn Hàn (**`초성 힌트`** — không dùng mẹo nhớ vặt), soi lỗi chính tả cấp độ ký tự **`Jamo`**, và sinh câu ghép đa từ cho cả các bài nhiều từ đơn (Bài 2–8).
- **Production:** Trích xuất hội thoại Chat thực tế từ `LESSON_DIALOGUES` cho đủ 8 bài, chấp nhận đa biến thể lịch sự/rút gọn (`-아요` $\leftrightarrow$ `-습니다`), kiểm tra trợ từ địa điểm `에/에서` & chia động từ, tùy chọn khay mảnh ghép từ gợi ý, và **nhận xét + đối đáp ngược bằng tiếng Hàn tự nhiên** (`완벽해요!`, `잘했어요!`).

### 📱 2. Tối Ưu Tương Thích iOS PWA Notch & Dynamic Island
- Xử lý toàn diện vùng an toàn `env(safe-area-inset-top)` khi thêm ứng dụng ra Màn hình chính (Add to Home Screen) trên iPhone/iPad.
- Khắc phục triệt để lỗi Header bị che khuất bởi tai thỏ / Dynamic Island khi chạy chế độ Standalone Web App (`apple-mobile-web-app-status-bar-style: black-translucent`).
- Tinh chỉnh chiều cao linh hoạt (`min-height: auto`), thanh tìm kiếm chuẩn `34px`, đảm bảo bấm chuẩn xác 100% tất cả các nút chức năng.

### 🎙️ 3. AI Pitch & Intonation Visualizer (Ngữ điệu K-ToBI Thời Gian Thực)
- Sử dụng Web Audio API và thuật toán Autocorrelation nhận diện tần số cơ bản (F0: 60Hz – 450Hz).
- Mô hình ngữ điệu chuẩn Seoul 1A (câu trần thuật hạ cung, câu hỏi vút cao, đuôi kính ngữ `-아요/어요`, trang trọng `-ㅂ니다/습니까`).
- **Đồ thị cao độ kép (Dual-Contour):** So sánh trực quan đường cong mẫu của người bản xứ và giọng nói của người học.
- Chuẩn hóa cao độ bằng độ lệch bán âm (Semitone), chấm điểm tương đồng ngữ điệu (0 – 100%) kèm thưởng XP khi đạt $\ge 85\%$.

### 🐕 4. Tủ Đồ Phụ Kiện Noli Shiba (Mở khóa theo tích lũy XP)
- Loại bỏ hệ thống 24 huy hiệu cũ rườm rà, thay thế bằng **Tủ đồ 10 Phụ kiện Noli độc quyền** mở khóa tuần tự theo điểm kinh nghiệm (XP):
  - 🧣 **Khăn Quàng Đỏ** (0 XP - Sẵn có mặc định)
  - 👓 **Kính Tròn Trí Thức** (100 XP)
  - 🎒 **Balo Đại Học SNU** (250 XP)
  - 🎧 **Tai Nghe K-Pop Studio** (500 XP)
  - ☕ **Cà Phê Đá Ah-Ah** (800 XP)
  - 🌸 **Cài Hoa Anh Đào Yeouido** (1.200 XP)
  - 🥋 **Đai Đen Taekwondo** (1.800 XP)
  - 👘 **Áo Hanbok Hoàng Gia** (2.500 XP)
  - 👑 **Vương Miện Vàng Shilla** (3.500 XP)
  - 🎓 **Mũ Cử Nhân Thủ Khoa SNU** (5.000 XP)
- **Tính năng Trang bị (Equip):** Người học tự do diện phụ kiện đã mở khóa cho Noli; hiển thị trực tiếp lên huy hiệu góc logo tại Header và Showcase Card.
- **Real-time Celebration Banner:** Pop-up chúc mừng sinh động xuất hiện tức thì mỗi khi vượt mốc XP mở khóa phụ kiện mới.

### 📱 5. P2P Zero-Server Data Sync (Đồng bộ Thiết bị qua Mã QR)
- Nén và mã hóa toàn bộ tiến trình học (Streak, XP, Sổ lỗi, Lịch ôn SRS) thành chuỗi Payload chuẩn Base64.
- Tạo mã QR độc lập bằng SVG vector, không cần server trung gian, không gửi dữ liệu ra ngoài.
- Dễ dàng chuyển tiến trình học giữa máy tính và điện thoại chỉ với một lần quét mã hoặc dán chuỗi dữ liệu.

### 💿 6. Kho CD Audio Gốc 32 Tracks & Máy Nghe Nhạc Chuyên Dụng
- Đầy đủ 32 track CD Audio phòng thu tương ứng với 8 bài học Seoul 1A (4 tracks/bài).
- Tích hợp cụm điều khiển âm thanh: chỉnh tốc độ phát (`0.8x`, `1.0x`, `1.2x`), tua lại/nhanh `±5 giây`, mini-player nổi khi cuộn trang.

### ⌨️ 7. Bàn Phím Ảo Tối Giản & Cặp Nút Nổi Cân Xứng
- Nút mở bàn phím ảo tinh gọn: loại bỏ chữ, chỉ giữ biểu tượng `⌨️` dạng tròn `48px`, bo góc `50%`.
- Cặp nút nổi bàn phím ảo và Bạn học AI Noli đặt cạnh nhau đối xứng ở góc dưới bên phải màn hình.
- Thanh Live Mirror Bar (`#vkLiveText`) soi trực quan từng chữ Hangul đang gõ, tự động cuộn trang (`scrollIntoView`) chống che khuất ô nhập liệu.

### 🧠 8. Active Recall & Production Luyện Viết
- Kho bài tập đa dạng chia thành các hiệp ngắn 12 câu: Điền từ, Trắc nghiệm, Sắp xếp câu, Gõ phím phản xạ, Luyện nghe.
- Động cơ phân tích lỗi sai Levenshtein thông minh và giải thích ngữ pháp tức thì.
- **Sổ tay sửa lỗi (Mistakes Notebook):** Tự động thu thập từ/câu làm sai, cho phép thi lại riêng và tự động "tốt nghiệp" khi trả lời đúng 2 lần liên tiếp.

---

## 🚀 Hướng Dẫn Chạy Ứng Dụng

Ứng dụng được thiết kế hoàn toàn tĩnh (Static PWA), không đòi hỏi cài đặt máy chủ:

### Cách 1: Mở trực tiếp (1-Click)
- Nhấn đúp chuột vào tệp **`Mo_NoliKorea_V7.html`** hoặc mở thẳng **`dist/index.html`** bằng trình duyệt bất kỳ (Chrome, Edge, Safari, Firefox).

### Cách 2: Khởi chạy Local Server bằng Python
```bash
python -m http.server 8000 --directory dist
```
Mở trình duyệt tại địa chỉ: `http://localhost:8000`

### Cách 3: Đưa lên GitHub Pages (Tự động)
1. Đẩy toàn bộ mã nguồn lên nhánh `main` của repository GitHub.
2. Vào **Settings** → **Pages** → **Build and deployment** → Source chọn: **GitHub Actions**.
3. Workflow `.github/workflows/pages.yml` sẽ tự động build và triển khai ứng dụng miễn phí.

---

## 📁 Cấu Trúc Thư Mục Repository

```
v7/
├── .github/workflows/          # Kịch bản tự động hóa GitHub Actions (Pages, Release)
├── .gitignore                  # Cấu hình bỏ qua tệp tạm, node_modules
├── .gitattributes              # Định dạng chuẩn hóa văn bản
├── package.json                # Cấu hình dự án (Phiên bản 7.1.0)
├── package-lock.json
├── content-corrections.json    # Bảng sửa lỗi phát âm và từ vựng
├── Mo_NoliKorea_V7.html        # Trình mở ứng dụng 1-click
├── README.md                   # Tài liệu hướng dẫn sử dụng V7
├── data/                       # Dữ liệu nguồn giáo trình Seoul 1A
│   └── curriculum.json
├── scripts/                    # Scripts build dữ liệu và kiểm thử
│   ├── build-content.cjs
│   ├── build-css.cjs
│   └── prepare-pages.cjs
├── tests/                      # Bộ kiểm thử tự động
└── dist/                       # Toàn bộ mã nguồn chạy thực tế của ứng dụng
    ├── index.html              # Màn hình giao diện chính (Lối tắt Dòng chảy vô tận)
    ├── sw.js                   # Service Worker Offline PWA (Cache kla-v7-1-0)
    ├── manifest.json           # Cấu hình PWA
    ├── assets/                 # Logo linh vật Noli Shiba chính thức
    ├── audio/snu1a/            # Track âm thanh CD gốc (Tracks 01–89)
    ├── modules/                # 27 module chức năng chuyên sâu (kèm infinite-stream.js)
    ├── styles/                 # Hệ thống bảng mã giao diện CSS (Tối ưu hóa Tai thỏ iOS)
    ├── keyboard.js             # Bàn phím ảo tiếng Hàn
    ├── recall.js               # Động cơ Active Recall
    ├── production.js           # Động cơ luyện viết & đối thoại 8 bài
    └── ai.js                   # Trợ lý học tập Noli AI
```

---

## 🛠️ Lệnh Phát Triển (Dành cho Lập Trình Viên)

Yêu cầu Node.js $\ge 22$:

```bash
# Cài đặt thư viện dev
npm ci

# Biên dịch nội dung giáo trình & đóng gói CSS
npm run build

# Chạy kiểm thử tự động
npm test
```

---

## 📄 Bản Quyền & Giấy Phép
Dự án được xây dựng phục vụ mục đích học tập cá nhân phi lợi nhuận. Giáo trình chuẩn tham khảo dựa trên bộ sách Seoul National University (SNU) Korean 1A.
