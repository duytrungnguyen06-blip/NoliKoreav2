# NoliKorea · V7.0.4

> **Ứng dụng tự học tiếng Hàn giao tiếp thực chiến theo giáo trình Đại học Quốc gia Seoul (Seoul 1A).**  
> Chạy hoàn toàn Offline (100% Local / Zero-Server Architecture), tích hợp PWA cài đặt trên máy tính & điện thoại di động, trợ lý AI thông minh Noli Shiba.

---

## 🌟 Điểm nổi bật trên Phiên bản V7.0.4

### 🎙️ 1. AI Pitch & Intonation Visualizer (Ngữ điệu K-ToBI Thời Gian Thực)
- Sử dụng Web Audio API và thuật toán Autocorrelation nhận diện tần số cơ bản (F0: 60Hz – 450Hz).
- Mô hình ngữ điệu chuẩn Seoul 1A (câu trần thuật hạ cung, câu hỏi vút cao, đuôi kính ngữ `-아요/어요`, trang trọng `-ㅂ니다/습니까`).
- **Đồ thị cao độ kép (Dual-Contour):** So sánh trực quan đường cong mẫu của người bản xứ và giọng nói của người học.
- Chuẩn hóa cao độ bằng độ lệch bán âm (Semitone), chấm điểm tương đồng ngữ điệu (0 – 100%) kèm thưởng XP khi đạt $\ge 85\%$.

### 🐕 2. Tủ Đồ Phụ Kiện Noli Shiba (Mở khóa theo tích lũy XP)
- Loại bỏ hệ thống 24 huy hiệu cũ rườm rà, thay thế bằng **Tủ đồ 10 Phụ kiện Noli độc quyền** mở khóa tuần tự theo điểm kinh nghiệm (XP):
  - 🧣 **Khăn Quàng Đỏ** (0 XP - Sẵn có mặc định)
  - 👓 **Kính Tròn Trí Thức** (100 XP)
  - 🎒 **Balo Đại Học SNU** (250 XP)
  - 🎧 **Tai Nghe K-Pop Studio** (500 XP)
  - ☕ **Cà Phê Đá Ah-Ah** (800 XP)
  - 🌸 **Cài Hoa Anh Đào Yeouido** (1.200 XP)
  - 🥋 **Đai Đen Taekwondo** (1.800 XP)
  - 👘 **Áo Hanbok Hoàng Gia** (2.500 XP)
  - 👑 **Vương Miện Vàng Shilla** (3.500 XP)
  - 🎓 **Mũ Cử Nhân Thủ Khoa SNU** (5.000 XP)
- **Tính năng Trang bị (Equip):** Người học tự do diện phụ kiện đã mở khóa cho Noli; hiển thị trực tiếp lên huy hiệu góc logo tại Header và Showcase Card.
- **Real-time Celebration Banner:** Pop-up chúc mừng sinh động xuất hiện tức thì mỗi khi vượt mốc XP mở khóa phụ kiện mới.

### 📱 3. P2P Zero-Server Data Sync (Đồng bộ Thiết bị qua Mã QR)
- Nén và mã hóa toàn bộ tiến trình học (Streak, XP, Sổ lỗi, Lịch ôn SRS) thành chuỗi Payload chuẩn Base64.
- Tạo mã QR độc lập bằng SVG vector, không cần server trung gian, không gửi dữ liệu ra ngoài.
- Dễ dàng chuyển tiến trình học giữa máy tính và điện thoại chỉ với một lần quét mã hoặc dán chuỗi dữ liệu.

### 💿 4. Kho CD Audio Gốc 32 Tracks & Máy Nghe Nhạc Chuyên Dụng
- Đầy đủ 32 track CD Audio phòng thu tương ứng với 8 bài học Seoul 1A (4 tracks/bài).
- Tích hợp cụm điều khiển âm thanh: chỉnh tốc độ phát (`0.8x`, `1.0x`, `1.2x`), tua lại/nhanh `±5 giây`, mini-player nổi khi cuộn trang.

### ⌨️ 5. Bàn Phím Ảo Tối Giản & Cặp Nút Nổi Cân Xứng
- Nút mở bàn phím ảo tinh gọn: loại bỏ chữ, chỉ giữ biểu tượng `⌨️` dạng tròn `48px`, bo góc `50%`.
- Cặp nút nổi bàn phím ảo và Bạn học AI Noli đặt cạnh nhau đối xứng ở góc dưới bên phải màn hình.
- Thanh Live Mirror Bar (`#vkLiveText`) soi trực quan từng chữ Hangul đang gõ, tự động cuộn trang (`scrollIntoView`) chống che khuất ô nhập liệu.

### 🧠 6. Active Recall & Production Luyện Viết
- Kho bài tập đa dạng chia thành các hiệp ngắn 12 câu: Điền từ, Trắc nghiệm, Sắp xếp câu, Gõ phím phản xạ, Luyện nghe.
- Động cơ phân tích lỗi sai Levenshtein thông minh và giải thích ngữ pháp tức thì.
- **Sổ tay sửa lỗi (Mistakes Notebook):** Tự động thu thập từ/câu làm sai, cho phép thi lại riêng và tự động "tốt nghiệp" khi trả lời đúng 2 lần liên tiếp.

---

## 🚀 Hướng Dẫn Chạy Ứng Dụng

Ứng dụng được thiết kế hoàn toàn tĩnh (Static PWA), không đòi hỏi cài đặt máy chủ:

### Cách 1: Mở trực tiếp (1-Click)
- Nhấn đúp chuột vào tệp **`Mo_NoliKorea_V7.html`** hoặc mở thẳng **`dist/index.html`** bằng trình duyệt bất kỳ (Chrome, Edge, Safari, Firefox).

### Cách 2: Khởi chạy Local Server bằng Python
```bash
python -m http.server 8000 --directory dist
```
Mở trình duyệt tại địa chỉ: `http://localhost:8000`

### Cách 3: Đưa lên GitHub Pages (Tự động)
1. Đẩy toàn bộ mã nguồn lên nhánh `main` của repository GitHub.
2. Vào **Settings** → **Pages** → **Build and deployment** → Source chọn: **GitHub Actions**.
3. Workflow `.github/workflows/pages.yml` sẽ tự động build và triển khai ứng dụng miễn phí.

---

## 📁 Cấu Trúc Thư Mục Repository

```
v7/
├── .github/workflows/          # Kịch bản tự động hóa GitHub Actions (Pages, Release)
├── .gitignore                  # Cấu hình bỏ qua tệp tạm, node_modules
├── .gitattributes              # Định dạng chuẩn hóa văn bản
├── package.json                # Cấu hình dự án (Phiên bản 7.0.4)
├── package-lock.json
├── content-corrections.json    # Bảng sửa lỗi phát âm và từ vựng
├── Mo_NoliKorea_V7.html        # Trình mở ứng dụng 1-click
├── README.md                   # Tài liệu hướng dẫn sử dụng V7
├── data/                       # Dữ liệu nguồn giáo trình Seoul 1A
│   └── curriculum.json
├── scripts/                    # Scripts build dữ liệu và kiểm thử
│   ├── build-content.cjs
│   ├── build-css.cjs
│   └── prepare-pages.cjs
├── tests/                      # Bộ kiểm thử tự động
└── dist/                       # Toàn bộ mã nguồn chạy thực tế của ứng dụng
    ├── index.html              # Màn hình giao diện chính
    ├── sw.js                   # Service Worker Offline PWA (Cache kla-v7-0-4)
    ├── manifest.json           # Cấu hình PWA
    ├── assets/                 # Logo linh vật Noli Shiba chính thức
    ├── audio/snu1a/            # 32 track âm thanh CD gốc
    ├── modules/                # 27 module chức năng chuyên sâu
    ├── styles/                 # Hệ thống bảng mã giao diện CSS
    ├── keyboard.js             # Bàn phím ảo tiếng Hàn
    ├── recall.js               # Động cơ Active Recall
    ├── production.js           # Động cơ luyện viết
    ├── ai.js                   # Trợ lý học tập Noli AI
    └── ...
```

---

## 🛠️ Lệnh Phát Triển (Dành cho Lập Trình Viên)

Yêu cầu Node.js $\ge 22$:

```bash
# Cài đặt thư viện dev
npm ci

# Biên dịch nội dung giáo trình & đóng gói CSS
npm run build

# Chạy kiểm thử tự động
npm test
```

---

## 📄 Bản Quyền & Giấy Phép
Dự án được xây dựng phục vụ mục đích học tập cá nhân phi lợi nhuận. Giáo trình chuẩn tham khảo dựa trên bộ sách Seoul National University (SNU) Korean 1A.
