#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "============================================================"
echo "  NOLIKOREA V6.0.0 FINAL - ĐẨY LÊN GITHUB TỰ ĐỘNG (1-CLICK)"
echo "============================================================"
echo ""

if ! command -v git >/dev/null 2>&1; then
  echo "[LỖI] Máy chưa cài Git. Hãy cài đặt Git trước khi chạy script này."
  exit 1
fi

echo "Bước 1: Tạo 1 Repository TRỐNG tại https://github.com/new (không tích chọn Add a README)."
read -rp "Bước 2: Dán URL Repository (VD: https://github.com/username/nolikorea.git): " REPO_URL

if [ -z "$REPO_URL" ]; then
  echo "[LỖI] Bạn chưa nhập URL Repository!"
  exit 1
fi

echo "[1/4] Đang khởi tạo Git và đóng gói mã nguồn..."
git init
git branch -M main
git add .
git commit -m "Release NoliKorea V6.0.0 Final" || true

echo "[2/4] Đang kết nối remote origin..."
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO_URL"

echo "[3/4] Đang đẩy nhánh main lên GitHub..."
git push -u origin main --force

echo "[4/4] Đang đẩy tag v6.0.0 để tự động tạo GitHub Release..."
git tag -f v6.0.0
git push origin v6.0.0 --force

echo ""
echo "============================================================"
echo "  HOÀN TẤT! Hãy vào Settings -> Pages -> Source: GitHub Actions"
echo "  trên kho GitHub của bạn để kích hoạt trang web PWA!"
echo "============================================================"
