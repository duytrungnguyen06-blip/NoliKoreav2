@echo off
chcp 65001 >nul
title NoliKorea V6.0.0 Final - Day len GitHub (1-Click)
echo ============================================================
echo   NOLIKOREA V6.0.0 FINAL - CONG CU DAY LEN GITHUB TU DONG
echo ============================================================
echo.

where git >nul 2>nul
if %errorlevel% neq 0 (
    echo [LOI] May tinh chua cai Git!
    echo Vui long tai va cai Git tai: https://git-scm.com/downloads
    pause
    exit /b 1
)

echo Buoc 1: Hay tao 1 Repository TRONG tren https://github.com/new
echo         (Dat ten vi du: nolikorea - KHONG tich chon Add a README file)
echo.
set /p REPO_URL="Buoc 2: Dan link HTTPS cua Repository (vd: https://github.com/ten-ban/nolikorea.git): "

if "%REPO_URL%"=="" (
    echo [LOI] Ban chua nhap link Repository!
    pause
    exit /b 1
)

echo.
echo [1/4] Dang khoi tao Git va chuan bi 206 tep du an...
git init
git branch -M main
git add .
git commit -m "Release NoliKorea V6.0.0 Final"

echo.
echo [2/4] Dang ket noi voi GitHub Repository: %REPO_URL%
git remote remove origin 2>nul
git remote add origin "%REPO_URL%"

echo.
echo [3/4] Dang day ma nguon len nhanh main...
git push -u origin main --force
if %errorlevel% neq 0 (
    echo.
    echo [LOI] Khong day duoc len GitHub. Hay kiem tra quyen dang nhap Git hoac URL!
    pause
    exit /b 1
)

echo.
echo [4/4] Dang day tag v6.0.0 de tao ban Release ZIP...
git tag -f v6.0.0
git push origin v6.0.0 --force

echo.
echo ============================================================
echo   HOAN TAT! DU AN DA DUOC DAY LEN GITHUB THANH CONG!
echo   Buoc cuoi cung de chay Web App tren GitHub Pages:
echo   1. Mo Repository tren GitHub -^> vao tab Settings -^> Pages
echo   2. Muc Build and deployment (Source): Chon "GitHub Actions"
echo   3. Cho ~1 phut trong tab Actions de nhan link Web App!
echo ============================================================
pause
